class MedicalRecordsViewer {
    constructor() {
        this.currentPage = 1;
        this.totalPages = document.querySelectorAll('.record-page').length;
        this.init();
    }

    init() {
        // Set total pages
        document.getElementById('totalPages').textContent = this.totalPages;

        // Add button listeners
        document.getElementById('prevPage').addEventListener('click', () => this.changePage(-1));
        document.getElementById('nextPage').addEventListener('click', () => this.changePage(1));

        // Add keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowRight') this.changePage(1);
            if (e.key === 'ArrowLeft') this.changePage(-1);
        });

        this.updateUI();
    }

    changePage(delta) {
        const newPage = this.currentPage + delta;
        if (newPage >= 1 && newPage <= this.totalPages) {
            // Hide current page
            document.querySelector(`.record-page[data-page="${this.currentPage}"]`).style.display = 'none';
            
            // Show new page
            this.currentPage = newPage;
            document.querySelector(`.record-page[data-page="${this.currentPage}"]`).style.display = 'block';
            
            this.updateUI();
        }
    }

    updateUI() {
        // Update page number
        document.getElementById('currentPage').textContent = this.currentPage;
        
        // Update button states
        document.getElementById('prevPage').disabled = this.currentPage === 1;
        document.getElementById('nextPage').disabled = this.currentPage === this.totalPages;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new MedicalRecordsViewer();
});