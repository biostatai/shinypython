from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from clinical_review.models import Case, CaseAssignment
from django.utils import timezone

class Command(BaseCommand):
    help = 'Loads sample clinical review cases and assigns them to user abc123'

    def handle(self, *args, **kwargs):
        # Create test user if doesn't exist
        username = 'abc123'
        try:
            user = User.objects.get(username=username)
            self.stdout.write(f'Using existing user: {username}')
        except User.DoesNotExist:
            user = User.objects.create_user(
                username=username,
                password='abc123',  # Set a default password
                first_name='Test',
                last_name='User',
                email='abc123@example.com'
            )
            self.stdout.write(f'Created new user: {username}')

        # Sample cases with real medical scenarios
        cases = [
            {
                'case_number': 'CR-2024-001',
                'patient_name': 'James Wilson',
                'clinician_summary': '''
72-year-old male presenting with increasing shortness of breath over 2 weeks. History of COPD, 
HTN, and CAD. Current smoker (1 ppd x 40 years). Using rescue inhaler 4-5 times daily. 
SpO2 92% on room air. Exam reveals diffuse wheezing and prolonged expiratory phase.
Recent COVID test negative. No fever or chest pain. Previous admission for COPD exacerbation 3 months ago.
                '''.strip(),
                'llm_summary': '''
72M w/progressive SOB x2wks
PMH: COPD, HTN, CAD
- Active smoker: 1ppd x 40yrs
- Rescue inhaler use ↑ (4-5x/day)
- O2 sat 92% RA
- Exam: diffuse wheezes, prolonged expiration
- COVID(-), afebrile
- Last COPD exacerbation: 3mo ago
                '''.strip(),
                'medical_records': '''
PMH: COPD (diagnosed 2010), HTN, CAD s/p CABG 2018
Meds:
- Symbicort 160/4.5 BID
- Spiriva 18mcg daily
- Albuterol PRN
- Lisinopril 20mg daily
- ASA 81mg daily
- Atorvastatin 40mg daily

Last PFTs (3 months ago):
FEV1: 45% predicted
FVC: 60% predicted
FEV1/FVC: 0.65
                '''.strip()
            },
            {
                'case_number': 'CR-2024-002',
                'patient_name': 'Emily Chen',
                'clinician_summary': '''
28-year-old female with type 1 diabetes presenting with nausea, vomiting, and abdominal pain for 24 hours. 
Blood glucose 320 mg/dL, bicarb 16, anion gap 18. Reports missing last 2 insulin doses due to empty pump reservoir. 
No fever. Last A1c 8.2%. History of diabetic ketoacidosis requiring 2 hospitalizations in past year.
                '''.strip(),
                'llm_summary': '''
28F T1DM w/:
- N/V, abd pain x24hrs
- BG: 320
- ↓bicarb (16), ↑AG (18)
- Missed insulin x2 doses (empty pump)
- Afebrile
- A1c: 8.2%
- h/o DKA x2 prior year
Assessment: Early DKA, needs admission
                '''.strip(),
                'medical_records': '''
PMH: T1DM (diagnosed age 12)
Recent Labs:
- Glucose: 320 mg/dL
- Na: 138
- K: 4.8
- Cl: 104
- CO2: 16
- BUN: 22
- Cr: 0.9
- Anion gap: 18
- Beta-hydroxybutyrate: 4.2
- pH: 7.28

Current Meds:
- Insulin pump (Medtronic)
- Basal rate: 0.8 units/hr
- Carb ratio: 1:8
                '''.strip()
            },
            {
                'case_number': 'CR-2024-003',
                'patient_name': 'Robert Taylor',
                'clinician_summary': '''
45-year-old male presents with acute onset chest pain starting 2 hours ago. Describes pain as pressure-like, 
radiating to left arm, associated with diaphoresis and SOB. History of hypertension and hyperlipidemia. 
Father had MI at age 50. Current BP 165/95, HR 98. Initial troponin negative, EKG shows ST elevation in V2-V4.
                '''.strip(),
                'llm_summary': '''
45M w/acute CP x2hrs:
- Pressure-like, radiating to L arm
- (+) diaphoresis, SOB
- PMH: HTN, HLD
- FHx: Father MI @50
- VS: BP 165/95, HR 98
- Trop neg (initial)
- EKG: STE in V2-V4
Assessment: STEMI until proven otherwise
                '''.strip(),
                'medical_records': '''
PMH: HTN, Hyperlipidemia
Meds:
- Lisinopril 20mg daily
- Atorvastatin 40mg daily

Vitals:
BP: 165/95
HR: 98
RR: 20
O2: 98% RA
Temp: 97.8F

Labs:
- Initial troponin: <0.01
- BMP: pending
- CBC: pending

EKG: 2mm ST elevation V2-V4
CXR: pending
                '''.strip()
            }
        ]

        # Create cases and assignments
        for case_data in cases:
            # Create or update case
            case, created = Case.objects.update_or_create(
                case_number=case_data['case_number'],
                defaults=case_data
            )
            
            # Create assignment if it doesn't exist
            assignment, a_created = CaseAssignment.objects.get_or_create(
                case=case,
                user=user,
                defaults={
                    'assigned_date': timezone.now(),
                    'is_completed': False
                }
            )

            status = 'Created' if created else 'Updated'
            self.stdout.write(f'{status} case: {case.case_number}')
            self.stdout.write(f'{"Created" if a_created else "Updated"} assignment for user {username}')

        total_cases = CaseAssignment.objects.filter(user=user).count()
        self.stdout.write(self.style.SUCCESS(f'Successfully loaded {total_cases} cases for user {username}'))
        self.stdout.write(self.style.SUCCESS(f'Login credentials: username={username}, password=abc123'))