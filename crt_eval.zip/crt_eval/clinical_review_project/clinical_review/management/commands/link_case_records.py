from django.core.management.base import BaseCommand
from django.conf import settings
import os
import fitz
from PIL import Image
import io
from clinical_review.models import Case

class PDFHandler:
    def __init__(self, dpi=300):
        self.zoom = dpi / 72
        self.dpi = dpi

    def convert_pdf_to_images(self, pdf_path, output_dir, img_format='png'):
        """Convert PDF to images and return list of image paths"""
        image_paths = []
        
        try:
            doc = fitz.open(pdf_path)
            
            for page_num in range(doc.page_count):
                page = doc[page_num]
                mat = fitz.Matrix(self.zoom, self.zoom)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                
                # Convert to PIL Image
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                
                # Create filename
                filename = f'page_{page_num + 1:03d}.{img_format}'
                filepath = os.path.join(output_dir, filename)
                
                # Save optimized image
                if img_format in ['jpg', 'jpeg']:
                    img.save(filepath, 'JPEG', quality=85, optimize=True)
                else:
                    img.save(filepath, 'PNG', optimize=True)
                
                image_paths.append(filepath)
            
            doc.close()
            return image_paths
            
        except Exception as e:
            raise Exception(f"Error converting PDF: {str(e)}")

class Command(BaseCommand):
    help = 'Links existing cases with their PDF medical records and converts them to images'

    def add_arguments(self, parser):
        parser.add_argument('pdf_dir', type=str, help='Directory containing PDF files')
        parser.add_argument('--dpi', type=int, default=300, help='DPI for image conversion')
        parser.add_argument('--format', type=str, default='png', help='Output image format (png or jpg)')
        parser.add_argument('--case', type=str, help='Specific case number to process (optional)')

    def handle(self, *args, **options):
        # Get absolute path of PDF directory
        pdf_dir = os.path.abspath(options['pdf_dir'])
        dpi = options['dpi']
        img_format = options['format'].lower()
        specific_case = options.get('case')

        # Verify PDF directory exists
        if not os.path.exists(pdf_dir):
            self.stdout.write(self.style.ERROR(f'PDF directory not found: {pdf_dir}'))
            return

        self.stdout.write(f"Using PDF directory: {pdf_dir}")
        
        # List available PDFs
        available_pdfs = [f for f in os.listdir(pdf_dir) if f.endswith('.pdf')]
        self.stdout.write(f"Found {len(available_pdfs)} PDFs: {', '.join(available_pdfs)}")

        pdf_handler = PDFHandler(dpi=dpi)

        # Get cases to process
        if specific_case:
            cases = Case.objects.filter(case_number=specific_case)
            if not cases.exists():
                self.stdout.write(self.style.ERROR(f'No case found with number {specific_case}'))
                return
        else:
            cases = Case.objects.all()

        self.stdout.write(f"Found {cases.count()} cases to process")

        # Create base output directory if it doesn't exist
        base_output_dir = os.path.join('clinical_review', 'static', 'medical_records')
        os.makedirs(base_output_dir, exist_ok=True)

        for case in cases:
            self.stdout.write(f"\nProcessing case: {case.case_number}")
            
            # Check for PDF file
            pdf_filename = f"{case.case_number}.pdf"
            pdf_path = os.path.join(pdf_dir, pdf_filename)
            
            if not os.path.exists(pdf_path):
                self.stdout.write(
                    self.style.WARNING(
                        f'No PDF found for case {case.case_number}\n'
                        f'Expected path: {pdf_path}'
                    )
                )
                continue

            # Create output directory for this case
            output_dir = os.path.join(base_output_dir, case.case_number)
            os.makedirs(output_dir, exist_ok=True)

            try:
                # Convert PDF to images
                image_paths = pdf_handler.convert_pdf_to_images(
                    pdf_path=pdf_path,
                    output_dir=output_dir,
                    img_format=img_format
                )

                # Update case record with the path
                case.medical_records_path = f'medical_records/{case.case_number}'
                case.save()

                self.stdout.write(
                    self.style.SUCCESS(
                        f'Successfully processed {case.case_number}:\n'
                        f'- PDF source: {pdf_path}\n'
                        f'- Output dir: {output_dir}\n'
                        f'- Pages converted: {len(image_paths)}'
                    )
                )

            except Exception as e:
                self.stdout.write(
                    self.style.ERROR(
                        f'Error processing case {case.case_number}:\n'
                        f'Error: {str(e)}'
                    )
                )

        self.stdout.write(self.style.SUCCESS('Finished processing cases'))