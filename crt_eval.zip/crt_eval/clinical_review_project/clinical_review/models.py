from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import os

class Case(models.Model):
    case_number = models.CharField(max_length=20, unique=True)
    patient_name = models.CharField(max_length=100)
    clinician_summary = models.TextField(blank=True)  # Made blank=True for new cases
    llm_summary = models.TextField(blank=True)  # Made blank=True for new cases
    medical_records_path = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        related_name='created_cases'
    )
    assigned_users = models.ManyToManyField(
        User, 
        through='CaseAssignment',
        related_name='assigned_cases'
    )

    def __str__(self):
        return f"{self.case_number} - {self.patient_name}"

    @property
    def review_count(self):
        return self.evaluation_set.count()
    
    def get_medical_record_images(self):
        """Returns a sorted list of image paths in the medical records folder"""
        if not self.medical_records_path:
            return []
        
        try:
            image_files = []
            full_path = os.path.join('medical_records', self.case_number)
            base_dir = os.path.join('clinical_review', 'static', full_path)
            
            if os.path.exists(base_dir):
                for file in sorted(os.listdir(base_dir)):
                    if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                        image_files.append(os.path.join(full_path, file))
            return image_files
        except Exception:
            return []

class CaseAssignment(models.Model):
    case = models.ForeignKey(Case, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    is_completed = models.BooleanField(default=False)
    assigned_date = models.DateTimeField(auto_now_add=True)
    completed_date = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = ['case', 'user']

class Evaluation(models.Model):
    RATING_CHOICES = [
        (1, 'Poor'),
        (2, 'Fair'),
        (3, 'Good'),
        (4, 'Very Good'),
        (5, 'Excellent')
    ]
    
    FINAL_ASSESSMENT_CHOICES = [
        ('highly_reliable', 'Approved - Highly Reliable'),
        ('minor_revisions', 'Approved with Minor Revisions Needed'),
        ('major_revisions', 'Major Revisions Required'),
        ('not_reliable', 'Not Reliable - Human Review Required')
    ]
    
    case = models.ForeignKey(Case, on_delete=models.CASCADE)
    evaluator = models.ForeignKey(User, on_delete=models.CASCADE)
    accuracy_rating = models.IntegerField(choices=RATING_CHOICES)
    completeness_rating = models.IntegerField(choices=RATING_CHOICES)
    clarity_rating = models.IntegerField(choices=RATING_CHOICES)
    discrepancies = models.TextField(blank=True)
    improvements = models.TextField(blank=True)
    final_assessment = models.CharField(max_length=20, choices=FINAL_ASSESSMENT_CHOICES)
    
    has_diagnosis_errors = models.BooleanField(default=False)
    has_treatment_errors = models.BooleanField(default=False)
    has_medication_errors = models.BooleanField(default=False)
    has_lab_errors = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Evaluation for {self.case} by {self.evaluator}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        assignment = CaseAssignment.objects.get(case=self.case, user=self.evaluator)
        if not assignment.is_completed:
            assignment.is_completed = True
            assignment.completed_date = timezone.now()
            assignment.save()