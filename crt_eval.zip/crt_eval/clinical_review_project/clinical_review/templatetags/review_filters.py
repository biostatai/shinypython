from django import template
from django.forms import BoundField

register = template.Library()

@register.filter
def get_field(form, field_name):
    return form[field_name]

@register.filter
def field_value(field):
    if isinstance(field, BoundField):
        return field.value() or ''
    return field or ''

@register.filter
def field_choices(field):
    return field.field.choices

@register.filter(name='split')
def split_filter(value, arg):
    """Split a string by argument"""
    return value.split(arg)

@register.filter(name='replace')
def replace_filter(value, arg):
    """Replace parts of a string. Argument format: 'old,new'"""
    if ',' in arg:
        old, new = arg.split(',')
        return value.replace(old, new)
    return value

@register.filter(name='as_hidden')
def as_hidden(field):
    """Render a form field as a hidden input"""
    return field.as_hidden()

@register.filter(name='stringformat')
def stringformat(value, arg):
    """Format a value using string format syntax"""
    try:
        return format(value, arg)
    except (ValueError, TypeError):
        return value
    
@register.filter(name='add')
def add_strings(value, arg):
    """Concatenate strings"""
    return str(value) + str(arg)