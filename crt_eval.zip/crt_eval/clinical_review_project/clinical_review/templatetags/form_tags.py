from django import template

register = template.Library()

@register.filter
def get_field(form, field_name):
    return form[field_name]

@register.filter
def field_value(field):
    return field.value() or ''

@register.filter
def field_choices(field):
    return field.field.choices

@register.filter
def split(value, arg):
    return value.split(arg)

@register.filter
def replace(value, arg):
    old, new = arg.split(',')
    return value.replace(old, new)

@register.filter
def as_hidden(field):
    return field.as_hidden()