from django import forms
from .models import Evaluation
class EvaluationForm(forms.ModelForm):
    discrepancy_tags = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'data-role': 'tagsinput'})
    )
    
    class Meta:
        model = Evaluation
        fields = [
            'accuracy_rating',
            'completeness_rating',
            'clarity_rating',
            'discrepancies',
            'improvements',
            'final_assessment',
            'has_diagnosis_errors',
            'has_treatment_errors',
            'has_medication_errors',
            'has_lab_errors'
        ]
        widgets = {
            'discrepancies': forms.Textarea(attrs={'class': 'materialize-textarea'}),
            'improvements': forms.Textarea(attrs={'class': 'materialize-textarea'}),
        }

from django import forms
from .models import Case

class CaseCreationForm(forms.ModelForm):
    medical_records = forms.FileField(
        help_text="Upload a PDF file of medical records",
        widget=forms.FileInput(attrs={'accept': 'application/pdf'})
    )

    class Meta:
        model = Case
        fields = ['patient_name', 'case_number']
        widgets = {
            'patient_name': forms.TextInput(attrs={'class': 'validate'}),
            'case_number': forms.TextInput(attrs={
                'class': 'validate',
                'placeholder': 'Auto-generated if left blank'
            })
        }

    def clean_case_number(self):
        case_number = self.cleaned_data.get('case_number')
        if not case_number:
            # Generate a case number based on the latest case
            latest_case = Case.objects.order_by('-created_at').first()
            if latest_case and latest_case.case_number:
                try:
                    num = int(latest_case.case_number.split('-')[-1])
                    case_number = f'CR-{timezone.now().year}-{num + 1:03d}'
                except ValueError:
                    case_number = f'CR-{timezone.now().year}-001'
            else:
                case_number = f'CR-{timezone.now().year}-001'
        return case_number