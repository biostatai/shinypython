import fitz
import os
from PIL import Image
import io
from django.conf import settings

class PDFHandler:
    def __init__(self, dpi=300):
        self.zoom = dpi / 72
        self.dpi = dpi

    def get_page_count(self, pdf_path):
        """Get the total number of pages in a PDF"""
        try:
            doc = fitz.open(pdf_path)
            count = doc.page_count
            doc.close()
            return count
        except Exception:
            return 0

    def convert_pdf_to_images(self, pdf_path, output_dir, img_format='png'):
        """Convert PDF to images and return list of image paths"""
        image_paths = []
        
        try:
            doc = fitz.open(pdf_path)
            
            for page_num in range(doc.page_count):
                page = doc[page_num]
                mat = fitz.Matrix(self.zoom, self.zoom)
                pix = page.get_pixmap(matrix=mat, alpha=False)
                
                # Convert to PIL Image
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                
                # Create filename
                filename = f'page_{page_num + 1:03d}.{img_format}'
                filepath = os.path.join(output_dir, filename)
                
                # Save optimized image
                if img_format in ['jpg', 'jpeg']:
                    img.save(filepath, 'JPEG', quality=85, optimize=True)
                else:
                    img.save(filepath, 'PNG', optimize=True)
                
                image_paths.append(filepath)
            
            doc.close()
            return image_paths
            
        except Exception as e:
            raise Exception(f"Error converting PDF: {str(e)}")

    def extract_page_text(self, pdf_path, page_num):
        """Extract text from a specific page"""
        try:
            doc = fitz.open(pdf_path)
            page = doc[page_num]
            text = page.get_text()
            doc.close()
            return text
        except Exception:
            return ""

    def get_page_dimensions(self, pdf_path, page_num=0):
        """Get dimensions of a specific page"""
        try:
            doc = fitz.open(pdf_path)
            page = doc[page_num]
            rect = page.rect
            doc.close()
            return (rect.width, rect.height)
        except Exception:
            return (0, 0)