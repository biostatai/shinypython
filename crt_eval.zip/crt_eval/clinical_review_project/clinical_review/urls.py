from django.urls import path
from . import views

app_name = 'clinical_review'

urlpatterns = [
    path('', views.case_list, name='case_list'),
    path('create/', views.create_case, name='create_case'),
    path('case/<int:case_id>/', views.case_detail, name='case_detail'),
    path('case/<int:case_id>/reviews/', views.case_reviews, name='case_reviews'),
    path('case/<int:case_id>/save/', views.save_evaluation, name='save_evaluation'),
]