class MedicalRecordsViewer {
    constructor() {
        this.currentPage = 1;
        this.totalPages = document.querySelectorAll('.record-page').length;
        this.init();
    }

    init() {
        // Set total pages
        document.getElementById('totalPages').textContent = this.totalPages;

        // Reset any existing styles on images
        document.querySelectorAll('.record-page img').forEach(img => {
            img.removeAttribute('style');
            img.style.maxWidth = '50%';
            img.style.maxHeight = '50%';
            img.style.width = 'auto';
            img.style.height = 'auto';
            img.style.objectFit = 'contain';
        });

        // Add button listeners
        document.getElementById('prevPage').addEventListener('click', () => this.changePage(-1));
        document.getElementById('nextPage').addEventListener('click', () => this.changePage(1));

        // Add keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowRight') this.changePage(1);
            if (e.key === 'ArrowLeft') this.changePage(-1);
        });

        this.updateUI();
    }

    changePage(delta) {
        const newPage = this.currentPage + delta;
        if (newPage >= 1 && newPage <= this.totalPages) {
            // Hide all pages first
            document.querySelectorAll('.record-page').forEach(page => {
                page.style.display = 'none';
            });
            
            // Show new page
            this.currentPage = newPage;
            const newPageElement = document.querySelector(`.record-page[data-page="${this.currentPage}"]`);
            if (newPageElement) {
                newPageElement.style.display = 'flex';
                // Reset image styles for the current page
                const currentImage = newPageElement.querySelector('img');
                if (currentImage) {
                    currentImage.removeAttribute('style');
                    currentImage.style.maxWidth = '50%';
                    currentImage.style.maxHeight = '50%';
                    currentImage.style.width = 'auto';
                    currentImage.style.height = 'auto';
                    currentImage.style.objectFit = 'contain';
                }
            }
            
            this.updateUI();
        }
    }

    updateUI() {
        // Update page number
        document.getElementById('currentPage').textContent = this.currentPage;
        
        // Update button states
        document.getElementById('prevPage').disabled = this.currentPage === 1;
        document.getElementById('nextPage').disabled = this.currentPage === this.totalPages;
    }
}

// Clear any existing instances before creating new one
document.addEventListener('DOMContentLoaded', () => {
    // Remove any existing styles from previous instances
    document.querySelectorAll('.record-page img').forEach(img => {
        img.removeAttribute('style');
    });
    
    // Initialize viewer
    new MedicalRecordsViewer();
});