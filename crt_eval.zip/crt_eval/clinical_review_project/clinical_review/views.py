from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from django.contrib import messages

def custom_logout(request):
    logout(request)
    messages.success(request, 'You have been successfully logged out.')
    return render(request, 'registration/logout.html')

from django.urls import reverse
from django.utils import timezone
from django.db.models import Count
from .models import Case, CaseAssignment, Evaluation
from .forms import CaseCreationForm, EvaluationForm
import os

@login_required
def case_list(request):
    # Get assigned cases
    assigned_cases = CaseAssignment.objects.filter(
        user=request.user
    ).select_related('case').order_by('-assigned_date')
    
    # Get created cases with evaluation count
    created_cases = Case.objects.filter(
        created_by=request.user
    ).annotate(
        evaluation_count=Count('evaluation')
    ).order_by('-created_at')
    
    context = {
        'assigned_cases': assigned_cases,
        'created_cases': created_cases,
    }
    
    return render(request, 'clinical_review/case_list.html', context)
@login_required
def create_case(request):
    if request.method == 'POST':
        form = CaseCreationForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                # Create case without saving to DB yet
                case = form.save(commit=False)
                case.created_by = request.user
                
                # Handle the PDF file
                pdf_file = request.FILES['medical_records']
                
                # Create directory for this case's files
                case_dir = f'medical_records/{case.case_number}'
                os.makedirs(os.path.join('clinical_review', 'static', case_dir), exist_ok=True)
                
                # Save PDF temporarily (in real implementation, you'd process it)
                pdf_path = os.path.join('clinical_review', 'static', case_dir, 'original.pdf')
                with open(pdf_path, 'wb+') as destination:
                    for chunk in pdf_file.chunks():
                        destination.write(chunk)
                
                # For demo: Create dummy clinician and LLM summaries
                case.clinician_summary = "Demo clinician summary for " + case.patient_name
                case.llm_summary = "Demo LLM summary for " + case.patient_name
                case.medical_records_path = case_dir
                
                # Save the case
                case.save()
                
                # Create a default assignment for the creator
                CaseAssignment.objects.create(
                    case=case,
                    user=request.user,
                    assigned_date=timezone.now()
                )
                
                return JsonResponse({
                    'status': 'success',
                    'redirect_url': reverse('clinical_review:case_detail', args=[case.id])
                })
                
            except Exception as e:
                return JsonResponse({
                    'status': 'error',
                    'error': str(e)
                })
        else:
            return JsonResponse({
                'status': 'error',
                'error': form.errors
            })
    else:
        form = CaseCreationForm()
    
    return render(request, 'clinical_review/create_case.html', {
        'form': form
    })

@login_required
def case_reviews(request, case_id):
    case = get_object_or_404(Case, id=case_id)
    reviews = Evaluation.objects.filter(case=case).select_related('evaluator')
    
    return render(request, 'clinical_review/case_reviews.html', {
        'case': case,
        'reviews': reviews
    })

@login_required
def case_detail(request, case_id):
    case = get_object_or_404(Case, id=case_id)
    assignment = get_object_or_404(CaseAssignment, case=case, user=request.user)
    
    # Get existing evaluation or None
    evaluation = Evaluation.objects.filter(
        case=case,
        evaluator=request.user
    ).first()
    
    if request.method == 'POST':
        form = EvaluationForm(request.POST, instance=evaluation)
        if form.is_valid():
            evaluation = form.save(commit=False)
            evaluation.case = case
            evaluation.evaluator = request.user
            evaluation.save()
            
            # Update assignment completion status
            if not assignment.is_completed:
                assignment.is_completed = True
                assignment.completed_date = timezone.now()
                assignment.save()
            
            messages.success(request, 'Evaluation saved successfully.')
            return JsonResponse({'status': 'success'})
        return JsonResponse({'status': 'error', 'errors': form.errors})
    else:
        form = EvaluationForm(instance=evaluation)
    
    context = {
        'case': case,
        'form': form,
        'assignment': assignment
    }
    return render(request, 'clinical_review/case_detail.html', context)

@login_required
def evaluation_history(request, case_id):
    case = get_object_or_404(Case, id=case_id)
    evaluations = case.evaluation_set.all().order_by('-created_at')
    return render(request, 'clinical_review/evaluation_history.html', {
        'case': case,
        'evaluations': evaluations
    })



@login_required
@require_POST
def save_evaluation(request, case_id):
    case = get_object_or_404(Case, id=case_id)
    form = EvaluationForm(request.POST)
    
    if form.is_valid():
        evaluation = form.save(commit=False)
        evaluation.case = case
        evaluation.evaluator = request.user
        evaluation.save()
        form.save_m2m()
        return JsonResponse({'status': 'success'})
    else:
        return JsonResponse({'status': 'error', 'errors': form.errors})
