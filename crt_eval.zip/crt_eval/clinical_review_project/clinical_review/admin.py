from django.contrib import admin
from .models import Case, Evaluation, CaseAssignment

@admin.register(Case)
class CaseAdmin(admin.ModelAdmin):
    list_display = ('case_number', 'patient_name', 'created_at')
    search_fields = ('case_number', 'patient_name')

@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    list_display = ('case', 'evaluator', 'final_assessment', 'created_at')
    list_filter = ('final_assessment', 'evaluator')

@admin.register(CaseAssignment)
class CaseAssignmentAdmin(admin.ModelAdmin):
    list_display = ('case', 'user', 'is_completed', 'assigned_date', 'completed_date')
    list_filter = ('is_completed', 'user')
    search_fields = ('case__case_number', 'user__username')