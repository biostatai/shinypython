import cv2
import numpy as np
from pdf_processor import ImagePreprocessor

def test_preprocessing_methods(image_path):
    """Test different preprocessing methods on an image."""
    # Read image
    img = cv2.imread(image_path)
    preprocessor = ImagePreprocessor()
    
    # Original grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite('1_grayscale.jpg', gray)
    
    # Adaptive thresholding
    binary_adaptive = preprocessor.preprocess_image(img)
    cv2.imwrite('2_binary_adaptive.jpg', binary_adaptive)
    
    # Otsu's method
    binary_otsu = preprocessor.preprocess_image_otsu(img)
    cv2.imwrite('3_binary_otsu.jpg', binary_otsu)
    
    print("Saved preprocessed images:")
    print("1. Grayscale: 1_grayscale.jpg")
    print("2. Adaptive Thresholding: 2_binary_adaptive.jpg")
    print("3. Otsu's Method: 3_binary_otsu.jpg")

if __name__ == "__main__":
    # Test with your image
    test_preprocessing_methods("output/page_1.jpg")