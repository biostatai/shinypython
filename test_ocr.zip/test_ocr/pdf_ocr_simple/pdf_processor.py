import fitz
import cv2
import numpy as np
from pathlib import Path
from typing import Optional

from layout_types import PageResult
from layout_analyzer import DocumentAnalyzer
from sequence_processor import PositionalTextSequencer

class PDFProcessingResult:
    """Stores and manages complete PDF processing results."""
    
    def __init__(self):
        self.pages: List[PageResult] = []
        self._combined_text: Optional[str] = None
    
    def add_page(self, page_result: PageResult):
        """Add a page result in the correct order."""
        self.pages.append(page_result)
        self._combined_text = None
    
    @property
    def combined_text(self) -> str:
        """Get the combined text from all pages in order."""
        if self._combined_text is None:
            texts = []
            for page in self.pages:
                page_header = f"\n=== Page {page.page_number + 1} ===\n"
                texts.append(page_header + page.formatted_text)
            self._combined_text = "\n".join(texts)
        return self._combined_text
    
    def save_visualizations(self, output_dir: str):
        """Save visualization images to the specified directory."""
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True, parents=True)
        
        for page in self.pages:
            image_path = output_path / f"page_{page.page_number + 1}.jpg"
            cv2.imwrite(
                str(image_path), 
                cv2.cvtColor(page.visualization, cv2.COLOR_RGB2BGR)
            )

class SequentialPDFProcessor:
    """Process PDF documents sequentially, extracting layout and text."""
    
    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.analyzer = DocumentAnalyzer()
        self.sequencer = PositionalTextSequencer()
    
    def _process_page(self, page_image: np.ndarray, page_number: int) -> PageResult:
        """Process a single PDF page."""
        try:
            layout_results, viz_image = self.analyzer.analyze(
                page_image, 
                return_plot=True
            )
            
            sequence_result = self.sequencer.sequence_text(layout_results)
            
            return PageResult(
                page_number=page_number,
                layout_results=layout_results,
                visualization=viz_image,
                formatted_text=sequence_result.formatted_text
            )
            
        except Exception as e:
            print(f"Error processing page {page_number + 1}: {str(e)}")
            raise
    
    def process_pdf(self, pdf_path: str,
                   output_dir: Optional[str] = None,
                   dpi: int = 300) -> PDFProcessingResult:
        """Process a PDF document sequentially."""
        results = PDFProcessingResult()
        
        try:
            if self.verbose:
                print(f"Opening PDF: {pdf_path}")
            
            pdf_doc = fitz.open(pdf_path)
            total_pages = len(pdf_doc)
            
            for page_num in range(total_pages):
                if self.verbose:
                    print(f"\nProcessing page {page_num + 1} of {total_pages}")
                
                try:
                    page = pdf_doc[page_num]
                    pix = page.get_pixmap(matrix=fitz.Matrix(dpi/72, dpi/72))
                    
                    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(
                        pix.height, pix.width, pix.n
                    )
                    
                    if img.shape[2] == 4:
                        img = cv2.cvtColor(img, cv2.COLOR_RGBA2RGB)
                    
                    page_result = self._process_page(img, page_num)
                    results.add_page(page_result)
                    
                    if self.verbose:
                        print(f"Successfully processed page {page_num + 1}")
                        print(f"Found {sum(len(v) for v in page_result.layout_results.values())} layout elements")
                        print(f"Extracted {len(page_result.formatted_text)} characters of text")
                
                except Exception as e:
                    print(f"Error processing page {page_num + 1}: {str(e)}")
                    continue
            
            if output_dir:
                if self.verbose:
                    print(f"\nSaving visualizations to {output_dir}")
                results.save_visualizations(output_dir)
            
            return results
            
        except Exception as e:
            print(f"Error processing PDF: {str(e)}")
            raise
        
        finally:
            if 'pdf_doc' in locals():
                pdf_doc.close()