import cv2
from paddleocr import PaddleOCR
import numpy as np
from typing import List, Tuple

class DocumentTextExtractor:
    """Extracts text from document layouts using PaddleOCR."""
    
    def __init__(self, lang='en', use_gpu=True):
        """Initialize OCR system with specified settings."""
        self.ocr = PaddleOCR(
            use_angle_cls=True,
            lang=lang,
            use_gpu=use_gpu,
            show_log=False
        )
    
    def _calculate_padding(self, box: np.ndarray, image_shape: Tuple[int, int], 
                         fixed_padding: int = 15) -> np.ndarray:
        """Calculate optimal padding for a box."""
        height, width = image_shape[:2]
        x1, y1, x2, y2 = box
        
        padded_box = np.array([
            max(0, x1 - fixed_padding),
            max(0, y1 - fixed_padding),
            min(width, x2 + fixed_padding),
            min(height, y2 + fixed_padding)
        ])
        
        return padded_box
    
    def _check_overlap(self, box1: np.ndarray, box2: np.ndarray) -> float:
        """Calculate IoU between two boxes."""
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        
        if x2 < x1 or y2 < y1:
            return 0.0
            
        intersection = (x2 - x1) * (y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        
        return intersection / (area1 + area2 - intersection)

    def extract_text_from_region(self, image: np.ndarray, box: np.ndarray, 
                               other_boxes: List[np.ndarray]) -> Tuple[str, np.ndarray]:
        """Extract text from a region with smart padding."""
        fixed_padding = 15
        padded_box = self._calculate_padding(box, image.shape, fixed_padding)
        
        overlapping_boxes = [
            other_box for other_box in other_boxes 
            if not np.array_equal(box, other_box) and 
            self._check_overlap(padded_box, other_box) > 0
        ]
        
        if overlapping_boxes:
            for reduced_padding in [12, 8, 4, 0]:
                test_box = self._calculate_padding(box, image.shape, reduced_padding)
                if max(self._check_overlap(test_box, ob) for ob in overlapping_boxes) < 0.1:
                    padded_box = test_box
                    break
        
        x1, y1, x2, y2 = map(int, padded_box)
        region = image[y1:y2, x1:x2]
        
        if region.size == 0:
            return "", padded_box
        
        try:
            result = self.ocr.ocr(region, cls=True)
            if not result or not result[0]:
                return "", padded_box
            
            text = ' '.join([line[1][0] for line in result[0]])
            return text, padded_box
        except Exception as e:
            print(f"Error in OCR: {e}")
            return "", padded_box