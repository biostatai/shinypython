import torch
import torchvision
import cv2
import numpy as np
from PIL import Image
import os
from collections import defaultdict
from huggingface_hub import snapshot_download
from typing import Union, Dict, List, Tuple, Optional

from layout_types import LayoutResult
from text_extractor import DocumentTextExtractor

class DocumentAnalyzer:
    """Analyzes document layout using YOLO and extracts text."""
    
    def __init__(self, model_path: Optional[str] = None, use_gpu: bool = True):
        """Initialize the document analyzer."""
        self.device = 'cuda' if torch.cuda.is_available() and use_gpu else 'cpu'
        
        self.id_to_names = {
            0: 'title', 1: 'plain text', 2: 'abandon', 3: 'figure',
            4: 'figure_caption', 5: 'table', 6: 'table_caption',
            7: 'table_footnote', 8: 'isolate_formula', 9: 'formula_caption'
        }
        
        if model_path is None:
            model_dir = snapshot_download(
                'juliozhao/DocLayout-YOLO-DocStructBench',
                local_dir='./models/DocLayout-YOLO-DocStructBench'
            )
            model_path = os.path.join(
                "models", "DocLayout-YOLO-DocStructBench",
                "doclayout_yolo_docstructbench_imgsz1024.pt"
            )
        
        from doclayout_yolo import YOLOv10
        self.model = YOLOv10(model_path)
        self.text_extractor = DocumentTextExtractor(use_gpu=use_gpu)
        
        print(f"Models loaded successfully on {self.device}")
    
    def analyze(self, image: Union[str, np.ndarray, Image.Image],
               conf_threshold: float = 0.25,
               iou_threshold: float = 0.45,
               return_plot: bool = False) -> Union[Dict[str, List[LayoutResult]],
                                                 Tuple[Dict[str, List[LayoutResult]], np.ndarray]]:
        """Analyze document layout and extract text."""
        if isinstance(image, str):
            image = cv2.imread(image)
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        elif isinstance(image, Image.Image):
            image = np.array(image)
        
        det_res = self.model.predict(
            image,
            imgsz=1024,
            conf=conf_threshold,
            device=self.device,
        )[0]
        
        boxes = det_res.__dict__['boxes'].xyxy
        classes = det_res.__dict__['boxes'].cls
        scores = det_res.__dict__['boxes'].conf
        
        indices = torchvision.ops.nms(
            boxes=torch.Tensor(boxes),
            scores=torch.Tensor(scores),
            iou_threshold=iou_threshold
        )
        
        boxes = boxes[indices].cpu().numpy()
        scores = scores[indices].cpu().numpy()
        classes = classes[indices].cpu().numpy()
        
        if len(boxes.shape) == 1:
            boxes = np.expand_dims(boxes, 0)
            scores = np.expand_dims(scores, 0)
            classes = np.expand_dims(classes, 0)
        
        results = defaultdict(list)
        for i, (box, class_id, score) in enumerate(zip(boxes, classes, scores)):
            class_name = self.id_to_names[int(class_id)]
            text, padded_box = self.text_extractor.extract_text_from_region(
                image, box, [b for j, b in enumerate(boxes) if j != i]
            )
            
            layout_result = LayoutResult(
                layout_type=class_name,
                box=box,
                padded_box=padded_box,
                score=score,
                text=text
            )
            results[class_name].append(layout_result)
        
        if not return_plot:
            return dict(results)
        
        viz_image = self._visualize_results(image, results)
        return dict(results), viz_image
    
    def _visualize_results(self, image: np.ndarray, 
                         results: Dict[str, List[LayoutResult]]) -> np.ndarray:
        """Generate visualization of layout analysis results."""
        output = image.copy()
        num_classes = len(self.id_to_names)
        colors = np.random.randint(0, 255, size=(num_classes, 3), dtype=np.uint8)
        
        for layout_type, layout_results in results.items():
            class_id = [k for k, v in self.id_to_names.items() if v == layout_type][0]
            color = tuple(map(int, colors[class_id]))
            
            for result in layout_results:
                x1, y1, x2, y2 = map(int, result.box)
                cv2.rectangle(output, (x1, y1), (x2, y2), color, 2)
                
                px1, py1, px2, py2 = map(int, result.padded_box)
                for i in range(px1, px2, 10):
                    cv2.line(output, (i, py1), (min(i + 5, px2), py1), color, 1)
                    cv2.line(output, (i, py2), (min(i + 5, px2), py2), color, 1)
                for i in range(py1, py2, 10):
                    cv2.line(output, (px1, i), (px1, min(i + 5, py2)), color, 1)
                    cv2.line(output, (px2, i), (px2, min(i + 5, py2)), color, 1)
                
                text_preview = result.text[:50] + "..." if len(result.text) > 50 else result.text
                label = f"{layout_type}: {result.score:.2f}\n{text_preview}"
                
                y_offset = y1
                for line in label.split('\n'):
                    (text_w, text_h), baseline = cv2.getTextSize(
                        line, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 2
                    )
                    cv2.rectangle(output,
                                (x1, y_offset-text_h-baseline-5),
                                (x1+text_w, y_offset),
                                color, -1)
                    cv2.putText(output, line,
                              (x1, y_offset-5),
                              cv2.FONT_HERSHEY_SIMPLEX,
                              0.5, (255,255,255), 2)
                    y_offset -= text_h + baseline + 5
        
        return output