from pdf_processor import SequentialPDFProcessor
import os
from PIL import Image, ImageDraw, ImageFont

def create_test_pdf():
    """Create a test PDF with text and layout elements."""
    img = Image.new('RGB', (800, 1000), color='white')
    d = ImageDraw.Draw(img)
    font = ImageFont.load_default()

    # Add title
    d.text((100, 50), "Test Document Title", font=font, fill='black')
    
    # Add two columns of text
    d.text((50, 150), "This is the first column of text.", font=font, fill='black')
    d.text((450, 150), "This is the second column of text.", font=font, fill='black')
    
    # Save as PDF
    pdf_path = "test_document.pdf"
    img.save(pdf_path, "PDF")
    return pdf_path

def main():
    # Create test PDF
    pdf_path = "./data/medical_record.pdf"

    # Initialize processor
    processor = SequentialPDFProcessor(verbose=True)
    
    try:
        # Process the PDF
        results = processor.process_pdf(
            pdf_path=pdf_path,
            output_dir="output",
            dpi=300
        )
        
        # Print results
        print("\nExtracted Text:")
        print("-" * 50)
        print(results.combined_text)
        
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        # Clean up test PDF
        if os.path.exists(pdf_path):
            os.remove(pdf_path)

if __name__ == "__main__":
    main()