from typing import List, Dict, Tuple
import numpy as np
from layout_types import TextElement, SequencingResult

class PositionalTextSequencer:
    """Sequences document text based on spatial position."""
    
    def __init__(self, column_gap_threshold: float = 50):
        """Initialize sequencer with layout parameters."""
        self.column_gap_threshold = column_gap_threshold
    
    def _convert_to_elements(self, layout_results: Dict) -> List[TextElement]:
        """Convert layout results to TextElement objects."""
        elements = []
        global_idx = 0
        
        for element_type, results in layout_results.items():
            for result in results:
                elements.append(TextElement(
                    text=result.text,
                    box=result.box,
                    element_type=element_type,
                    confidence=result.score,
                    original_index=global_idx
                ))
                global_idx += 1
        return elements
    
    def sequence_text(self, layout_results: Dict) -> SequencingResult:
        """
        Generate reading sequence based on spatial position and layout structure.
        
        Sequencing rules:
        1. Full-width elements are processed in top-to-bottom order
        2. For non-full-width elements:
            - If no horizontal overlap exists, treat as multi-column
            - Process each column top-to-bottom, left-to-right
        3. Elements within same vertical position are processed left-to-right
        """
        elements = self._convert_to_elements(layout_results)
        if not elements:
            return SequencingResult("", [])
        
        # Calculate page dimensions
        page_width = max(elem.box[2] for elem in elements)
        page_height = max(elem.box[3] for elem in elements)
        
        def has_vertical_overlap(elem1, elem2, overlap_threshold=0.3):
            """Check if two elements overlap vertically."""
            top = max(elem1.box[1], elem2.box[1])
            bottom = min(elem1.box[3], elem2.box[3])
            if top >= bottom:
                return False
            
            overlap_height = bottom - top
            min_height = min(elem1.box[3] - elem1.box[1], 
                           elem2.box[3] - elem2.box[1])
            return overlap_height / min_height >= overlap_threshold
        
        def is_horizontally_aligned(elem1, elem2, tolerance=0.1):
            """Check if two elements are roughly at the same horizontal position."""
            y1_mid = (elem1.box[1] + elem1.box[3]) / 2
            y2_mid = (elem2.box[1] + elem2.box[3]) / 2
            height = max(elem1.box[3] - elem1.box[1], 
                        elem2.box[3] - elem2.box[1])
            return abs(y1_mid - y2_mid) <= height * tolerance
        
        # Separate full-width and partial-width elements
        full_width_elements = []
        partial_width_elements = []
        
        for elem in elements:
            elem_width = elem.box[2] - elem.box[0]
            if elem_width > page_width * 0.7:
                full_width_elements.append(elem)
            else:
                partial_width_elements.append(elem)
        
        # Sort full-width elements top-to-bottom
        full_width_elements.sort(key=lambda e: e.box[1])
        
        # Process partial-width elements to detect columns
        columns = []
        if partial_width_elements:
            # Sort by x, then y coordinates
            partial_width_elements.sort(key=lambda e: (e.box[0], e.box[1]))
            
            # Detect columns by analyzing horizontal gaps
            current_column = [partial_width_elements[0]]
            min_gap = page_width * 0.1  # Minimum gap for separate columns
            
            for elem in partial_width_elements[1:]:
                # Check if element starts a new column
                prev_right = max(e.box[2] for e in current_column)
                if elem.box[0] - prev_right > min_gap and not any(
                    has_vertical_overlap(elem, e) for e in current_column):
                    columns.append(current_column)
                    current_column = [elem]
                else:
                    # Check for vertical overlap with current column elements
                    overlaps = False
                    for e in current_column:
                        if has_vertical_overlap(elem, e):
                            if elem.box[0] > e.box[2]:
                                overlaps = True
                                break
                    
                    if not overlaps:
                        current_column.append(elem)
                    else:
                        if elem.box[0] - prev_right > min_gap:
                            columns.append(current_column)
                            current_column = [elem]
                        else:
                            current_column.append(elem)
            
            if current_column:
                columns.append(current_column)
            
            # Sort elements within each column by vertical position
            for column in columns:
                column.sort(key=lambda e: e.box[1])
        
        # Combine everything in reading order
        result_text = []
        ordered_elements = []
        
        def add_element(elem):
            """Add element with appropriate spacing."""
            if result_text and not result_text[-1].endswith('\n\n'):
                if ordered_elements and ordered_elements[-1].element_type != elem.element_type:
                    result_text.append('\n')
            result_text.append(elem.text.strip())
            ordered_elements.append(elem)
            result_text.append('\n')
        
        # Process full-width elements and columns in order
        full_width_idx = 0
        column_positions = [0] * len(columns)
        
        while True:
            candidates = []
            
            # Check full-width elements
            if full_width_idx < len(full_width_elements):
                candidates.append(('full', full_width_idx, full_width_elements[full_width_idx]))
            
            # Check each column
            for col_idx, column in enumerate(columns):
                if column_positions[col_idx] < len(column):
                    elem = column[column_positions[col_idx]]
                    candidates.append(('col', col_idx, elem))
            
            if not candidates:
                break
            
            # Sort candidates by vertical position
            candidates.sort(key=lambda x: x[2].box[1])
            
            # Process the topmost element
            elem_type, idx, element = candidates[0]
            add_element(element)
            
            # Update position
            if elem_type == 'full':
                full_width_idx += 1
            else:
                column_positions[idx] += 1
        
        return SequencingResult(
            formatted_text='\n'.join(text for text in result_text if text.strip()),
            ordered_elements=ordered_elements
        )