from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional, Union
import numpy as np

@dataclass
class LayoutResult:
    """Data class for layout analysis results."""
    layout_type: str
    box: np.ndarray  # [x1, y1, x2, y2]
    padded_box: np.ndarray
    score: float
    text: str

@dataclass
class TextElement:
    """Data class for text elements with spatial information."""
    text: str
    box: np.ndarray  # [x1, y1, x2, y2]
    element_type: str
    confidence: float
    original_index: int

@dataclass
class SequencingResult:
    """Data class for text sequencing results."""
    formatted_text: str
    ordered_elements: List[TextElement]

@dataclass
class PageResult:
    """Data class for single page processing results."""
    page_number: int
    layout_results: Dict
    visualization: np.ndarray
    formatted_text: str