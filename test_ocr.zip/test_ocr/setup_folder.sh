#!/bin/bash

# Create main directory
mkdir -p pdf_ocr_simple
cd pdf_ocr_simple

# Create Python files
touch layout_types.py
touch text_extractor.py
touch layout_analyzer.py
touch sequence_processor.py
touch pdf_processor.py
touch main.py

# Create directories for outputs and models
mkdir -p models
mkdir -p output